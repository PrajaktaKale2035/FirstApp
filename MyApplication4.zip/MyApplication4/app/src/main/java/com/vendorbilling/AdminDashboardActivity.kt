package com.vendorbilling

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class AdminDashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_dashboard)

        findViewById<Button>(R.id.product_management).setOnClickListener {
            startActivity(Intent(this, ProductManagementActivity::class.java))
        }

        findViewById<Button>(R.id.receipt_generation).setOnClickListener {
            startActivity(Intent(this, ReceiptGenerationActivity::class.java))
        }

        findViewById<Button>(R.id.transaction_history).setOnClickListener {
            startActivity(Intent(this, TransactionHistoryActivity::class.java))
        }
    }
}