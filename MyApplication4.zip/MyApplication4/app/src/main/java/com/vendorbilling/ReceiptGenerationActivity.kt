package com.vendorbilling

import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.vendorbilling.database.DatabaseHelper
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReceiptGenerationActivity : AppCompatActivity() {
    private lateinit var buyerNameEditText: EditText
    private lateinit var productNameEditText: EditText
    private lateinit var quantityEditText: EditText
    private lateinit var receiptTextView: TextView
    private lateinit var shareButton: Button
    private lateinit var printButton: Button
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receipt_generation)

        dbHelper = DatabaseHelper(this)
        initializeViews()
    }

    private fun initializeViews() {
        buyerNameEditText = findViewById(R.id.buyer_name)
        productNameEditText = findViewById(R.id.product_name)
        quantityEditText = findViewById(R.id.quantity)
        receiptTextView = findViewById(R.id.receipt_text)
        shareButton = findViewById(R.id.share_receipt)
        printButton = findViewById(R.id.print_receipt)

        shareButton.setOnClickListener { shareReceipt() }
        printButton.setOnClickListener { printReceiptAsPdf() }
    }

    fun generateReceipt(view: View) {
        val buyerName = buyerNameEditText.text.toString()
        val productName = productNameEditText.text.toString()
        val quantity = quantityEditText.text.toString().toDoubleOrNull() ?: return

        val db = dbHelper.readableDatabase
        val productCursor = db.query(
            "products",
            arrayOf("rate_per_kg"),
            "name = ?",
            arrayOf(productName),
            null, null, null
        )

        if (productCursor.moveToFirst()) {
            val ratePerKg = productCursor.getDouble(0)
            val currentPayment = quantity * ratePerKg
            val outstandingBalance = getOutstandingBalance(db, buyerName)
            val totalPayment = currentPayment + outstandingBalance

            val receipt = generateReceiptText(
                buyerName, productName, quantity,
                currentPayment, outstandingBalance, totalPayment
            )
            receiptTextView.text = receipt

            saveTransaction(
                db, buyerName, productName, quantity,
                currentPayment, totalPayment
            )

            shareButton.isEnabled = true
            printButton.isEnabled = true
        } else {
            Toast.makeText(this, "Product not found", Toast.LENGTH_SHORT).show()
        }
        productCursor.close()
        db.close()
    }

    private fun getOutstandingBalance(db: SQLiteDatabase, buyerName: String): Double {
        val balanceCursor = db.query(
            "transactions",
            arrayOf("SUM(outstanding_balance)"),
            "buyer_name = ?",
            arrayOf(buyerName),
            null, null, null
        )

        return if (balanceCursor.moveToFirst()) balanceCursor.getDouble(0) else 0.0
    }

    private fun generateReceiptText(
        buyerName: String, productName: String, quantity: Double,
        currentPayment: Double, outstandingBalance: Double, totalPayment: Double
    ): String = """
        Receipt
        Buyer: $buyerName
        Product: $productName
        Quantity: $quantity kg
        Current Payment: ₹$currentPayment
        Outstanding Balance: ₹$outstandingBalance
        Total Payment: ₹$totalPayment
    """.trimIndent()

    private fun saveTransaction(
        db: SQLiteDatabase, buyerName: String, productName: String,
        quantity: Double, currentPayment: Double, totalPayment: Double
    ) {
        val transactionValues = ContentValues().apply {
            put("buyer_name", buyerName)
            put("product_name", productName)
            put("quantity", quantity)
            put("payment_amount", currentPayment)
            put("outstanding_balance", totalPayment)
        }

        db.insert("transactions", null, transactionValues)
    }

    private fun shareReceipt() {
        val receiptText = receiptTextView.text.toString()
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, receiptText)
            putExtra(Intent.EXTRA_SUBJECT, "Sales Receipt")
        }
        startActivity(Intent.createChooser(sendIntent, "Share Receipt"))
    }

    private fun printReceiptAsPdf() {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(300, 600, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        val paint = Paint()
        paint.color = Color.BLACK
        paint.textSize = 12f

        val lines = receiptTextView.text.toString().split("\n")
        lines.forEachIndexed { index, line ->
            canvas.drawText(line, 20f, 50f + index * 25f, paint)
        }

        pdfDocument.finishPage(page)

        val fileName = "receipt_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.pdf"
        val file = File(getExternalFilesDir(null), fileName)

        try {
            val fos = FileOutputStream(file)
            pdfDocument.writeTo(fos)
            fos.close()
            pdfDocument.close()

            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "PDF Generation Failed", Toast.LENGTH_SHORT).show()
        }
    }
}
