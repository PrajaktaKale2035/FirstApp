package com.vendorbilling

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class LoginActivity : AppCompatActivity() {
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        usernameEditText = findViewById(R.id.username)
        passwordEditText = findViewById(R.id.password)
    }

    fun login(view: View) {
        val email = usernameEditText.text.toString()
        val password = passwordEditText.text.toString()

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        // Show loading indicator if you have one

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Get current user ID
                    val userId = auth.currentUser?.uid

                    // Check user role in Firebase Realtime Database
                    userId?.let { uid ->
                        FirebaseDatabase.getInstance().reference
                            .child("users")
                            .child(uid)
                            .child("role")
                            .get()
                            .addOnSuccessListener { snapshot ->
                                val userRole = snapshot.value as? String

                                if (userRole == "admin") {
                                    // Navigate to admin dashboard
                                    val intent = Intent(this, AdminDashboardActivity::class.java)
                                    startActivity(intent)
                                    finish()
                                } else {
                                    // Handle non-admin users
                                    Toast.makeText(this, "Unauthorized access", Toast.LENGTH_SHORT).show()
                                    auth.signOut()
                                }
                            }
                            .addOnFailureListener {
                                Toast.makeText(this, "Error checking user role", Toast.LENGTH_SHORT).show()
                                auth.signOut()
                            }
                    }
                } else {
                    // If sign in fails, display a message to the user
                    Toast.makeText(this, "Authentication failed", Toast.LENGTH_SHORT).show()
                }
            }
    }
}