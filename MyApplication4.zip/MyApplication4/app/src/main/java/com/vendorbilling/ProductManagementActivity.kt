package com.vendorbilling

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vendorbilling.database.DatabaseHelper

class ProductManagementActivity : AppCompatActivity() {
    private lateinit var productNameEditText: EditText
    private lateinit var rateEditText: EditText
    private lateinit var quantityEditText: EditText
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_management)

        dbHelper = DatabaseHelper(this)
        productNameEditText = findViewById(R.id.product_name)
        rateEditText = findViewById(R.id.rate_per_kg)
        quantityEditText = findViewById(R.id.quantity)
    }

    fun updateProduct(view: View) {
        val productName = productNameEditText.text.toString()
        val rate = rateEditText.text.toString().toDoubleOrNull() ?: return
        val quantity = quantityEditText.text.toString().toDoubleOrNull() ?: return

        val db: SQLiteDatabase = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("name", productName)
            put("rate_per_kg", rate)
            put("quantity", quantity)
        }

        val result = db.insertWithOnConflict("products", null, values, SQLiteDatabase.CONFLICT_REPLACE)

        if (result != -1L) {
            Toast.makeText(this, "Product Updated Successfully", Toast.LENGTH_SHORT).show()
            clearFields()
        } else {
            Toast.makeText(this, "Error Updating Product", Toast.LENGTH_SHORT).show()
        }
        db.close()
    }

    private fun clearFields() {
        productNameEditText.text.clear()
        rateEditText.text.clear()
        quantityEditText.text.clear()
    }
}