package com.vendorbilling

import android.os.Bundle
import android.widget.ListView
import android.widget.SimpleCursorAdapter
import androidx.appcompat.app.AppCompatActivity
import com.vendorbilling.database.DatabaseHelper

class TransactionHistoryActivity : AppCompatActivity() {
    private lateinit var transactionListView: ListView
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transaction_history)

        dbHelper = DatabaseHelper(this)
        transactionListView = findViewById(R.id.transaction_list)

        displayTransactionHistory()
    }

    private fun displayTransactionHistory() {
        val db = dbHelper.readableDatabase
        val cursor = db.query(
            "transactions",
            null, null, null, null, null,
            "transaction_date DESC"
        )

        val fromColumns = arrayOf(
            "transaction_date", "buyer_name",
            "product_name", "quantity",
            "payment_amount", "outstanding_balance"
        )

        val toViews = intArrayOf(
            R.id.transaction_date, R.id.buyer_name,
            R.id.product_name, R.id.quantity,
            R.id.payment_amount, R.id.outstanding_balance
        )

        val adapter = SimpleCursorAdapter(
            this, R.layout.transaction_list_item,
            cursor, fromColumns, toViews, 0
        )

        transactionListView.adapter = adapter
    }
}